public class JAVA1 {
    public  static  void  main(String args[]) {
        B b=new B();
        b.f();
        b.g();
    }
}
