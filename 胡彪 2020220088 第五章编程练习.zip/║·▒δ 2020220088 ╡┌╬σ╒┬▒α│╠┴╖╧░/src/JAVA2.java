public class JAVA2 {
    public static void main(String args[]) {
        C a=new C();
        D b=new D();
        System.out.println("最大公约数："+a.f(11,22));
        System.out.println("最小公倍数："+b.f(33,44));
    }
}
