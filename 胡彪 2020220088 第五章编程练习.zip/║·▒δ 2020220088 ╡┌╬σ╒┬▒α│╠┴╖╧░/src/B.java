class B extends A {
    public  void g() {
        char cStart = 'α', cEnd = 'ω';
        for (char c = cStart; c <= cEnd; c++) {
            System.out.print("" + c);
        }
    }
}
