class A {
    public final void f() {
        char cStart='a',cEnd='z';
        for(char c=cStart;c<=cEnd;c++) {
        System.out.print(""+c);
        }
    }
}
