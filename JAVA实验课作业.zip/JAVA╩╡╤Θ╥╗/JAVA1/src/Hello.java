public class Hello {
	public static void main (String args[ ]) {
		System.out.println("��ã��ܸ���ѧϰJAVA");
	
		A a=new A();
		a.fA();
	}
}
class A {

	public void fA() {
		System.out.println("We are students");
		
	}
}
